<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:1234567890"><i class="fas fa-phone"></i><span>+8801812659703</span></a>
         <a href="tel:1112223333"><i class="fas fa-phone"></i><span>+8801820115555</span></a>
         <a href="mailto:shaikhanas@gmail.com"><i class="fas fa-envelope"></i><span>shebapro@gmail.com</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span>Dhaka, Bangladesh</span></a>
      </div>

      <div class="box">
         <a href="home.php"><span>Home</span></a>
         <a href="about.php"><span>About</span></a>
         <a href="contact.php"><span>Contact</span></a>
         <a href="listings.php"><span>All Listings</span></a>
      </div>

      <div class="box">
         <a href="https://www.facebook.com/sadiq.bhuiyan.5/" target="_blank"><span>Facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>Twitter</span><i class="fab fa-twitter"></i></a>
         <a href="https://www.linkedin.com/in/sadiq-uddin-bhuiyan-09ba96263?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3B%2FiO3VERsTqezIrlxmyOlGA%3D%3D" target="_blank"><span>Linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="#"><span>Instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

</footer>

<!-- footer section ends -->